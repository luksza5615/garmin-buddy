import streamlit as st
from app.services.db_service import execute_azure

if st.button("Refresh data"):
    execute_azure()

st.title("Hello")
